-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 14, 2021 at 03:26 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gkpm`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `c_id` int(11) UNSIGNED NOT NULL,
  `c_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`c_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`c_id`, `c_data`) VALUES
(1, '{\"name\": \"gk ltd.\"}');

-- --------------------------------------------------------

--
-- Table structure for table `c_d`
--

CREATE TABLE `c_d` (
  `c_id` int(11) UNSIGNED NOT NULL,
  `d_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `c_d`
--

INSERT INTO `c_d` (`c_id`, `d_id`) VALUES
(1, 3),
(1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `c_p`
--

CREATE TABLE `c_p` (
  `c_id` int(11) UNSIGNED NOT NULL,
  `p_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `c_p`
--

INSERT INTO `c_p` (`c_id`, `p_id`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `d_id` int(11) UNSIGNED NOT NULL,
  `d_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`d_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`d_id`, `d_data`) VALUES
(1, '{\"name\": \"html\"}'),
(2, '{\"name\": \"css\"}'),
(3, '{\"name\": \"javascript\"}'),
(4, '{\"name\": \"php\"}');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `e_id` int(11) UNSIGNED NOT NULL,
  `tasks` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`tasks`))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`e_id`, `tasks`) VALUES
(1, '{\"tasks\": [{\"start\": \"\", \"status\": \"\", \"duration\": \"\", \"description\": \"\"}]}'),
(2, '{\"tasks\": [{\"start\": \"\", \"status\": \"\", \"duration\": \"\", \"description\": \"\"}]}'),
(3, '{\"tasks\": []}');

-- --------------------------------------------------------

--
-- Table structure for table `e_d`
--

CREATE TABLE `e_d` (
  `e_id` int(10) UNSIGNED NOT NULL,
  `d_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `e_d`
--

INSERT INTO `e_d` (`e_id`, `d_id`) VALUES
(1, 3),
(2, 4),
(3, 4);

-- --------------------------------------------------------

--
-- Table structure for table `e_p`
--

CREATE TABLE `e_p` (
  `e_id` int(11) UNSIGNED NOT NULL,
  `p_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `e_p`
--

INSERT INTO `e_p` (`e_id`, `p_id`) VALUES
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `p_id` int(11) UNSIGNED NOT NULL,
  `p_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`p_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`p_id`, `p_data`) VALUES
(1, '{\"name\": \"Website improvement\"}'),
(2, '{\"name\": \"Corona Hotel\"}');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `login` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(15) COLLATE utf8_unicode_ci NOT NULL COMMENT 'לא מוצפן',
  `dt` datetime NOT NULL DEFAULT current_timestamp(),
  `info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`info`))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `dt`, `info`) VALUES
(1, 'gk', '123', '2021-09-02 00:28:25', '{\"role\": \"pm\"}'),
(2, 'Dav', '234', '2021-09-01 19:14:16', '{\"role\": \"tl\"}'),
(3, 'David', '345', '2021-09-01 18:00:18', '{\"role\": \"tw\"}'),
(4, 'admin', 'ad1', '2021-09-10 08:56:47', '{\"role\": \"ad\"}');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `c_d`
--
ALTER TABLE `c_d`
  ADD KEY `cc2` (`c_id`,`d_id`);

--
-- Indexes for table `c_p`
--
ALTER TABLE `c_p`
  ADD KEY `cc1` (`c_id`,`p_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`e_id`);

--
-- Indexes for table `e_d`
--
ALTER TABLE `e_d`
  ADD KEY `ee1` (`e_id`,`d_id`);

--
-- Indexes for table `e_p`
--
ALTER TABLE `e_p`
  ADD KEY `ee2` (`e_id`,`p_id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u1` (`login`,`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `c_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `d_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `p_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
